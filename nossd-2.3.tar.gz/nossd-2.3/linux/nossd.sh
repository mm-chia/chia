#!/usr/bin/env bash

cd "$(dirname "$(realpath "${BASH_SOURCE[0]:-$0}")")"

#./client -d /mnt/ramdisk0 --no-temp --no-mining --no-stop -c 14
#./client -d /mnt/ramdisk0 --no-temp --no-mining --no-stop -c 14 -g,100M A4000
#./client -d /mnt/ramdisk0 --no-temp --no-mining --no-stop -c 14 -g,100M 229
#./client -d /mnt/ramdisk0 --no-temp --no-mining --no-stop -c 14
#./client -d /mnt/chia/2JJ6019C -d /mnt/chia/Y6G5234C -d /mnt/chia/9MH0EHWJ -d /mnt/chia/ZR900ZWA --no-temp --no-mining --no-stop -c 14 -g,100M 229

./client -d /mnt/ramdisk0 --no-temp --no-mining --no-stop -c 14 -g,100M A2000

#./client -d /mnt/ramdisk0 --no-temp --no-mining --no-stop -c 14

#./client -d /mnt/chia/WSD2Z5ZN -d /mnt/chia/WSD30WMR -d /mnt/chia/1EJP6X1Z -d /mnt/chia/VKHAM5VX --no-temp
